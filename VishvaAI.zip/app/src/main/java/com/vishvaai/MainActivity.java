package com.vishvaai;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.provider.Settings;
import android.hardware.biometrics.BiometricPrompt;

public class MainActivity extends Activity {
    private TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView tv = new TextView(this);
        tv.setText("VishvaAI is starting...");
        setContentView(tv);

        launchBiometricPrompt();

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.speak("Welcome back. VishvaAI is now active.", TextToSpeech.QUEUE_FLUSH, null, null);
            
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.util.concurrent.Executor;

private void launchBiometricPrompt() {
    Executor executor = ContextCompat.getMainExecutor(this);
    BiometricPrompt biometricPrompt = new BiometricPrompt(MainActivity.this,
        executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                Toast.makeText(getApplicationContext(), "Biometric verified", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(getApplicationContext(), "Verification failed", Toast.LENGTH_SHORT).show();
            }
        });

    BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
        .setTitle("VishvaAI Lock")
        .setSubtitle("Verify with Eye or Fingerprint")
        .setDeviceCredentialAllowed(true)
        .build();

    biometricPrompt.authenticate(promptInfo);
}

}
        
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.util.concurrent.Executor;

private void launchBiometricPrompt() {
    Executor executor = ContextCompat.getMainExecutor(this);
    BiometricPrompt biometricPrompt = new BiometricPrompt(MainActivity.this,
        executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                Toast.makeText(getApplicationContext(), "Biometric verified", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(getApplicationContext(), "Verification failed", Toast.LENGTH_SHORT).show();
            }
        });

    BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
        .setTitle("VishvaAI Lock")
        .setSubtitle("Verify with Eye or Fingerprint")
        .setDeviceCredentialAllowed(true)
        .build();

    biometricPrompt.authenticate(promptInfo);
}

});

        // Launch biometric validation
        // Placeholder: Actual biometric logic to be added
    
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.util.concurrent.Executor;

private void launchBiometricPrompt() {
    Executor executor = ContextCompat.getMainExecutor(this);
    BiometricPrompt biometricPrompt = new BiometricPrompt(MainActivity.this,
        executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                Toast.makeText(getApplicationContext(), "Biometric verified", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(getApplicationContext(), "Verification failed", Toast.LENGTH_SHORT).show();
            }
        });

    BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
        .setTitle("VishvaAI Lock")
        .setSubtitle("Verify with Eye or Fingerprint")
        .setDeviceCredentialAllowed(true)
        .build();

    biometricPrompt.authenticate(promptInfo);
}

}

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.shutdown();
        
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.util.concurrent.Executor;

private void launchBiometricPrompt() {
    Executor executor = ContextCompat.getMainExecutor(this);
    BiometricPrompt biometricPrompt = new BiometricPrompt(MainActivity.this,
        executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                Toast.makeText(getApplicationContext(), "Biometric verified", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(getApplicationContext(), "Verification failed", Toast.LENGTH_SHORT).show();
            }
        });

    BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
        .setTitle("VishvaAI Lock")
        .setSubtitle("Verify with Eye or Fingerprint")
        .setDeviceCredentialAllowed(true)
        .build();

    biometricPrompt.authenticate(promptInfo);
}

}
        super.onDestroy();
    
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.util.concurrent.Executor;

private void launchBiometricPrompt() {
    Executor executor = ContextCompat.getMainExecutor(this);
    BiometricPrompt biometricPrompt = new BiometricPrompt(MainActivity.this,
        executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                Toast.makeText(getApplicationContext(), "Biometric verified", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(getApplicationContext(), "Verification failed", Toast.LENGTH_SHORT).show();
            }
        });

    BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
        .setTitle("VishvaAI Lock")
        .setSubtitle("Verify with Eye or Fingerprint")
        .setDeviceCredentialAllowed(true)
        .build();

    biometricPrompt.authenticate(promptInfo);
}

}

import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.util.concurrent.Executor;

private void launchBiometricPrompt() {
    Executor executor = ContextCompat.getMainExecutor(this);
    BiometricPrompt biometricPrompt = new BiometricPrompt(MainActivity.this,
        executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                Toast.makeText(getApplicationContext(), "Biometric verified", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(getApplicationContext(), "Verification failed", Toast.LENGTH_SHORT).show();
            }
        });

    BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
        .setTitle("VishvaAI Lock")
        .setSubtitle("Verify with Eye or Fingerprint")
        .setDeviceCredentialAllowed(true)
        .build();

    biometricPrompt.authenticate(promptInfo);
}

}
